Place your cleaned dataset here as `cleaned_transactions.csv` if you want it to load by default.
You can also upload a CSV or JSON from the website sidebar.
